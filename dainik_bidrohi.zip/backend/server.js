
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });
const file = './news.json';

// Get news with optional category filter
app.get('/news', (req, res) => {
  fs.readFile(file, (err, data) => {
    if (err) return res.status(500).send("Error reading news");
    let news = JSON.parse(data);
    if (req.query.category) {
      news = news.filter(n => n.category === req.query.category);
    }
    res.send(news);
  });
});

// Post news with image and category
app.post('/news', upload.single('image'), (req, res) => {
  const { title, content, category } = req.body;
  const image = req.file ? `/uploads/${req.file.filename}` : null;
  const date = new Date().toLocaleString("bn-BD");
  const newNews = { title, content, category, image, date };

  fs.readFile(file, (err, data) => {
    const news = JSON.parse(data || '[]');
    news.push(newNews);
    fs.writeFile(file, JSON.stringify(news), () => {
      res.send({ message: 'News added successfully' });
    });
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
